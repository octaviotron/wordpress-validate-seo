# Single Source of Truth (SSOT) — WordPress SEO Validation Plugin

> This document defines the **stable, abstract foundations** of the project.
> It must NOT contain feature-specific decisions (e.g., which SEO plugin to target,
> which meta fields to check, or which post types to scope). Those belong in the prompt.
>
> **Guiding principle:** _"Would this still be true if the feature set changed entirely?"_
> If yes → it belongs here. If no → it belongs in the prompt.

---

## 1. Project Identity

| Field              | Value                                                     |
|--------------------|-----------------------------------------------------------|
| Plugin Name (EN)   | SEO Validation                                            |
| Plugin Name (ES)   | Validación SEO                                            |
| Slug / Directory   | `wordpress-validate-seo`                                  |
| Repository URL     | https://github.com/octaviotron/wordpress-validate-seo     |
| Author             | Octavio Rossell                                           |
| Author URI         | https://github.com/octaviotron                            |
| Text Domain        | `wordpress-validate-seo`                                  |
| Domain Path        | `/languages`                                              |
| License            | GPL-2.0-or-later                                          |
| License URI        | https://www.gnu.org/licenses/gpl-2.0.html                 |

---

## 2. Infrastructure & Architecture

### 2.1 Zero-Build Philosophy

This project uses **NO build toolchain**. There is no NPM, no Node.js, no JSX, no compilation step, and no `package.json`. All code is written in native PHP and vanilla JavaScript that runs directly in the browser without transpilation.

- **Development Environment:** Local machine; code is edited and deployed directly.
- **Production Environment:** Remote Linux Server (Docker-based WordPress instance).
- **Deployment Model:** Copy plugin files directly to `wp-content/plugins/`. No compilation is required on any environment.

### 2.2 Native WordPress JavaScript Architecture

WordPress exposes all its `@wordpress/*` packages as global `wp.*` objects inside the Block Editor. This plugin accesses them via destructuring from `window.wp`:

| NPM Import (NOT used)                  | Native Global Equivalent            |
|----------------------------------------|--------------------------------------|
| `import { registerPlugin } from '@wordpress/plugins'` | `wp.plugins.registerPlugin`     |
| `import { PluginPostStatusInfo } from '@wordpress/edit-post'` | `wp.editPost.PluginPostStatusInfo` |
| `import { useSelect, useDispatch } from '@wordpress/data'` | `wp.data.useSelect`, `wp.data.useDispatch` |
| `import { createElement, useEffect, useState } from '@wordpress/element'` | `wp.element.createElement`, `wp.element.useEffect`, `wp.element.useState` |
| `import { Notice, Button } from '@wordpress/components'` | `wp.components.Notice`, `wp.components.Button` |
| `import { __ } from '@wordpress/i18n'` | `wp.i18n.__`                        |

All JavaScript MUST be wrapped in an IIFE that receives `window.wp` to ensure safe access:
```javascript
( function( wp ) {
    const { registerPlugin } = wp.plugins;
    // ... component code ...
} )( window.wp );
```

### 2.3 UI Rendering Without JSX

Since there is no build step, JSX cannot be used. All UI rendering must use `wp.element.createElement` (aliased as `el` by convention):

```javascript
const el = wp.element.createElement;

// Instead of: <Button variant="secondary">Click</Button>
// Write:      el( Button, { variant: 'secondary' }, 'Click' )

// Nesting:    el( 'div', { className: 'wrapper' },
//                 el( Notice, { status: 'error', isDismissible: false }, message ),
//                 el( Button, { variant: 'secondary', onClick: handler }, label )
//             )
```

### 2.4 Script Enqueuing & Dependencies

Without an asset file, script dependencies are declared manually in `wp_enqueue_script()`. The required WordPress script handles for Block Editor integration are:

```php
$dependencies = array(
    'wp-plugins',
    'wp-edit-post',
    'wp-element',
    'wp-data',
    'wp-components',
    'wp-i18n',
);
```

Version cache-busting uses `filemtime()` on the JS file to automatically invalidate browser caches during development:
```php
$version = filemtime( plugin_dir_path( __FILE__ ) . 'js/editor.js' );
```

---

## 3. Repository Layout

```text
.
├── wordpress-validate-seo.php  # Main PHP: plugin header, hooks, enqueuing
├── js/
│   └── editor.js               # Vanilla JS: Block Editor integration (no build)
├── languages/                  # Translation catalogs
│   ├── wordpress-validate-seo.pot
│   ├── wordpress-validate-seo-es_ES.po
│   ├── wordpress-validate-seo-es_ES.mo
│   └── wordpress-validate-seo-es_ES-wordpress-validate-seo-script.json
├── Makefile                    # Packaging and i18n commands
├── .gitignore                  # Git tracking rules
├── README.md                   # Repository documentation (Spanish)
├── AI-SSOT.md                  # This file — Single Source of Truth
├── prompt.txt                  # AI agent instructions (mutable)
└── dist/                       # Packaged ZIP releases (git-ignored)
    └── wordpress-validate-seo.zip
```

---

## 4. Versioning Strategy (SemVer)

- **Current Version:** `0.1.0`
- **Single Source of Version:** The plugin header in `wordpress-validate-seo.php` is the canonical version. A PHP constant `WORDPRESS_VALIDATE_SEO_VERSION` is defined immediately after the header and used for all programmatic references.
- **Version Progression Rules:**
  - **Patch** (`0.1.1`, `0.1.2`): Bug fixes, small UI adjustments, translation corrections.
  - **Minor** (`0.2.0`, `0.3.0`): New validation rules, additional post-type support, new integrations.
  - **Major** (`1.0.0`): Stable release candidate, public API commitments.
- **Synchronization:** Version changes MUST be synchronized across:
  - `wordpress-validate-seo.php` (plugin header AND the `WORDPRESS_VALIDATE_SEO_VERSION` constant)
  - `README.md` (documented version)

---

## 5. Coding Standards & Conventions

### PHP
- Follow **WordPress PHP Coding Standards (WPCS)**.
- Minimum PHP version: `7.4`.
- Use `snake_case` for function and variable names.
- Prefix all global functions and constants with `wordpress_validate_seo_`.
- No direct use of `$_GET`, `$_POST`, `$_REQUEST` without sanitization functions.

### JavaScript
- Follow **WordPress JavaScript Coding Standards**.
- Use vanilla ES6+ syntax (arrow functions, destructuring, template literals, optional chaining).
- **No JSX** — use `wp.element.createElement` exclusively (aliased as `el`).
- **No npm imports** — access WordPress APIs via the global `wp.*` object.
- Use React hooks (`useEffect`, `useState`, `useSelect`, `useDispatch`) via `wp.element` and `wp.data`.
- Wrap all code in an IIFE receiving `window.wp`.
- Use `wp.i18n.__()` for all user-facing strings.

### Naming Conventions (Derived from Slug)

| Element               | Convention                                      |
|------------------------|-------------------------------------------------|
| Script handle          | `wordpress-validate-seo-script`                |
| Lock ID                | `wordpress-validate-seo-lock`                  |
| Plugin registration ID | `wordpress-validate-seo`                       |
| PHP function prefix    | `wordpress_validate_seo_`                      |
| PHP constant prefix    | `WORDPRESS_VALIDATE_SEO_`                      |
| CSS class prefix       | `wvs-`                                         |
| Translation domain     | `wordpress-validate-seo`                       |

### Plugin Header (PHP)
- Must be a DocBlock comment (`/** ... */`) at the top of the main PHP file.
- Required fields: `Plugin Name`, `Plugin URI`, `Description`, `Version`, `Requires at least`, `Requires PHP`, `Author`, `Author URI`, `License`, `License URI`, `Text Domain`, `Domain Path`.
- Must be immediately followed by the ABSPATH guard, then the version constant.

---

## 6. Architectural Principles & Constraints

### 6.1 API-Only Integration
- **MUST** use official WordPress Block Editor global APIs (`wp.data`, `wp.plugins`, `wp.editPost`) to interact with the editor.
- **MUST NOT** resort to direct DOM manipulation, CSS visibility hacks, or jQuery for core validation logic.
- **Controlled exception:** Targeted DOM access (e.g., `scrollIntoView`, `focus()`) is permitted ONLY for user-experience aids (navigating to a specific input field) and must be wrapped in null-safe checks.

### 6.2 State Management
- All editor state must be read via `wp.data` selectors (using `wp.data.useSelect` hook inside components).
- All editor mutations must use `wp.data` dispatchers (using `wp.data.useDispatch` hook inside components).
- Post-saving locks use the `core/editor` store: `lockPostSaving(LOCK_ID)` / `unlockPostSaving(LOCK_ID)`.
- **Mandatory cleanup:** Any `useEffect` that calls `lockPostSaving` MUST include a cleanup function that calls `unlockPostSaving` to prevent permanent lockouts on component unmount.

### 6.3 Scope Enforcement
- The plugin must restrict its behavior to specific post types.
- **PHP gate:** Check `get_current_screen()->post_type` inside the `enqueue_block_editor_assets` hook before enqueuing scripts.
- **JS defensive check:** Additionally verify `wp.data.select('core/editor').getCurrentPostType()` inside the component for extra safety.
- The specific post types to target are defined in the prompt, not here.

### 6.4 Graceful Degradation
- The plugin MUST NOT crash or break the editor if a third-party dependency (e.g., an SEO plugin) is not installed or activated.
- If the expected meta fields are absent, the plugin should either degrade silently or display an informational notice — never throw an error.
- Always check for the existence of data before accessing it (`?.` optional chaining, null checks).

### 6.5 UI Slot Selection
- Use `wp.editPost.PluginPostStatusInfo` for persistent validation feedback (always visible in the Document sidebar).
- Use `wp.editPost.PluginPrePublishPanel` for pre-publish checklists (shown in the pre-publish flyout).
- **NEVER** use `PluginPostPublishPanel` for validation — it renders only after a successful publish, which never occurs when saving is locked.
- Be aware: when `lockPostSaving` is active, WordPress disables the "Publish…" header button, which means `PluginPrePublishPanel` may not be reachable. Use `PluginPostStatusInfo` as the primary feedback slot.

### 6.6 Component API Compliance (WordPress 6.x+)
- Use `variant: 'secondary'` on Button props, not the deprecated `isSecondary`.
- Use `variant: 'primary'` on Button props, not the deprecated `isPrimary`.
- Prefer `Notice` with `status` prop (`'error'`, `'success'`, `'warning'`, `'info'`) for validation messages.
- Set `isDismissible: false` on validation notices to prevent the user from dismissing mandatory feedback.

---

## 7. Security Standards

- **ABSPATH Guard:** The main PHP file must exit immediately if `ABSPATH` is not defined:
  ```php
  if ( ! defined( 'ABSPATH' ) ) {
      exit;
  }
  ```
- **Capability Checks:** Any admin-facing settings or AJAX handlers must verify user capabilities via `current_user_can()`.
- **Nonce Verification:** Any form submissions or AJAX requests must include and verify nonces.
- **Data Sanitization:** All input must be sanitized with appropriate WordPress functions (`sanitize_text_field()`, `absint()`, etc.).
- **Output Escaping:** All output must be escaped with appropriate functions (`esc_html()`, `esc_attr()`, `wp_kses()`, etc.).

---

## 8. i18n / l10n Standards

- **Primary Source Language:** English.
- **Localization Support:** Dual-language (English base, Spanish translation).
- **PHP Translation Loading:** `load_plugin_textdomain()` on `init` or `plugins_loaded`.
- **JS Translation Loading:** `wp_set_script_translations()` linked to the script handle, text domain, and `/languages` path.
- **Translation File Types:**

  | File | Purpose | Generated By |
  |------|---------|--------------|
  | `.pot` | Template with source strings | `wp i18n make-pot` (WP-CLI) |
  | `.po`  | Human-editable translations | Translated from `.pot` via Poedit or text editor |
  | `.mo`  | Compiled binary for PHP translations | `msgfmt` or Poedit |
  | `.json` | JS translations for `wp_set_script_translations()` | `wp i18n make-json` (WP-CLI) |

- **JSON Translation File Naming:** `{text-domain}-{locale}-{script-handle}.json`
  - Example: `wordpress-validate-seo-es_ES-wordpress-validate-seo-script.json`
- **Tools Required:** WP-CLI with the `i18n` command package (no npm needed).
- **String Rules:**
  - All user-facing strings must be wrapped in `__()`, `_e()`, `_x()`, `_n()`, or `sprintf()` with the text domain.
  - In JS: use `wp.i18n.__( 'string', 'wordpress-validate-seo' )`.
  - Never concatenate translatable strings — use `sprintf()` with placeholders.

---

## 9. Dependency Compatibility Matrix

| Dependency       | Minimum Version | Notes                                                     |
|------------------|-----------------|-----------------------------------------------------------|
| WordPress        | 6.0             | Block Editor APIs, modern SlotFill system, `wp.*` globals |
| PHP              | 7.4             | Typed properties, arrow functions                         |
| WP-CLI (dev)     | 2.8+            | Required for `wp i18n make-pot` and `wp i18n make-json`   |

> Third-party plugin dependencies (e.g., SEO plugins) are NOT listed here.
> They are feature-specific and must be declared in the prompt.

---

## 10. Packaging & Distribution

- **No npm or build step** is required for packaging.
- Distributable ZIP archives are created using `make zip` (via Makefile) or a direct `zip` command.
- The Makefile defines packaging, i18n, and cleanup targets.
- The `dist/` directory is git-ignored and used solely for generated ZIP files.

---

## 11. Prompt Interface Contract

> This section defines what the **prompt** (mutable instruction file) **MUST specify**
> when requesting code generation. The AI agent should refuse or ask for clarification
> if any required field is missing.

### Required Fields

| Field                    | Description                                                          | Example                          |
|--------------------------|----------------------------------------------------------------------|----------------------------------|
| **Target Version**       | The SemVer version to generate                                       | `0.1.0`                         |
| **Objective**            | What this version accomplishes (behavioral, not implementation)      | "Prevent publishing without SEO keyphrase" |
| **Integration Target**   | Which third-party plugin/API to integrate with                       | Yoast SEO                       |
| **Validation Rules**     | What conditions to check and what to block                           | Focus keyphrase must be non-empty |
| **Scope**                | Which post types and editor contexts to target                       | `post` only, Block Editor only  |
| **UI Feedback**          | What the user should see in valid/invalid states                     | Error notice + navigation button |
| **Acceptance Criteria**  | How to verify the generated code works                               | Lock activates when field is empty |

### Optional Fields

| Field                    | Description                                                          |
|--------------------------|----------------------------------------------------------------------|
| **Meta Keys**            | Specific database meta keys to read                                  |
| **DOM Targets**          | Specific element IDs for UX navigation (controlled exception)        |
| **Additional Languages** | Translation languages beyond English + Spanish                       |
| **Post-Generation Tasks**| Commands to execute after code generation                            |
